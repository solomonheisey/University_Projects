java -jar GameOfLifeBuggy.jar 5 mock
