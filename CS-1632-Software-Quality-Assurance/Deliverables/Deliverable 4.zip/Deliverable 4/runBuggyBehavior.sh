java -jar GameOfLifeBuggy.jar 5 behavior
