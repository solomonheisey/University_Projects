import java.util.*;

public class World {

	public World(int size) {

	}

	public World(ArrayList<String> lines) {

	}

}
