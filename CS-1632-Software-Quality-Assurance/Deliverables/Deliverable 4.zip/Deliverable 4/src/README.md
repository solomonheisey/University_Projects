# SlowLifeGUI
Conway's Game of Life, in GUI Form.  Deliberately non-performant.
